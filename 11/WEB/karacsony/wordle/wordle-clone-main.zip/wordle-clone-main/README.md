# Wordle Clone

As the title suggests, this repository is a another iteration of the insanely popular game, Wordle. For the very few who haven't ever played it before, do check this out https://www.nytimes.com/games/wordle/index.html to learn the rules of the game.

## Tech Stack

This project uses HTML,CSS,JS and P5.JS

## How to run

1. Fork this repository
2. Navigate to the forked repository then clone it.
3. Open index.html with a browser

### Maintained by: [Nigel Dias](https://github.com/nigeldias27)
