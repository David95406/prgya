from ctypes.wintypes import PINT


a = float(input("addj meg egy fasz szamot "))
b = int(input("Addhj meg egy fasz szamor tereorwdfjksfnln"))

print(a)
print(b)