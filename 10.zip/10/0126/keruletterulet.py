from time import *
from random import *

x = 0
y = 0
r = 0
etel = ["perec", "kalács"]
szamolo = [1, 3]


def kerulet():
    kerulet = x + y
    print("A négyzet kerülete: ", kerulet)
def terulet():
    terulet = x * y
    print("A négyzet területe: ", terulet)
    
def korker():
    korker = 2 * r * 3,14
    print("A kör kerülete: ", korker)
    
def etel(): 
    print(etel)
    
def szam():
    szamolo.append
    
x = int(input("Addja meg a négyzet x oldalát! "))
y = int(input("Addja meg a négyzet y oldalát! "))

kerulet()
terulet()

r = int(input("Addja meg a sugarat! "))
korker()
etel()

