file = open("0310/golok.txt", "r", encoding="utf8()")

file.readline()
#stbstb... code meg minden

file.close()