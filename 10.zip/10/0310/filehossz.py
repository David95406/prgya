db = 0

with open("0310/test.txt", "r", encoding="utf8()") as test:
    for a in test:
        db += 1
        
print(db)