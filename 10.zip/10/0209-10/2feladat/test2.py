szam = 72
oszt = 1
while szam % oszt == 0:
    szam = szam / oszt
    oszt = oszt + 1
    print(szam, oszt)
print("A szam prim")