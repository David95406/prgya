from unittest.main import MAIN_EXAMPLES


print("Addjon meg három számot! ")
a = int(input("$"))
b = int(input("$"))
c = int(input("$"))
maximum = max(a, b, c)