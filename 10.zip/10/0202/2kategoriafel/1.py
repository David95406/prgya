a = int(12.3)
print(a)