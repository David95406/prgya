fk = input("$")
if "a" in fk:
    print(f"A(z) {fk} szó tartalmaz 'a' betut.")
else:
    print(f"A(z) {fk} szó nem tartalmaz 'a' betut.")