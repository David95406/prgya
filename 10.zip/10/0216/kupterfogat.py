from math import *
def qpV(r:float, m:float) -> float:
    return ((r * r) * pi * m) / 3
print(qpV(r=10, m=20))