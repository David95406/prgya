szam = 12

for a in range(1, szam):
    print("asd")