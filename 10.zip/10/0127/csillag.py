x = 2 #oszlop
y = 5 #sor
for a in range(x):
    print("*", end=" ")
    for b in range(y):
        print("*", end=" ")
    print("")