﻿-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!

-- 9. feladat:


-- 11. feladat:


-- 12. feladat:


-- 13. feladat:


-- 14. feladat:

 
-- 15. feladat:

