szam = 32489
print(szam.split(""))