class Hegyek:
    nev: str
    mag: int
    
    def __init__(self, adat) -> None:
        print("asd")