file1 = open("0316/write.txt")
file1.write("auhhhhh")



file1.close()