print("Leon átmegy a vizsgán?")
import random, time
a = random.randint(0,1)
if a == 1:
	print("Átmegysz")
else:
	print("Megbukiksz")

time.sleep(100)