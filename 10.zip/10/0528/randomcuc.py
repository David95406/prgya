from math import sqrt
szam = 0

while True:
    szam += 1
    print(szam)
    print(sqrt(szam))
    print(pow(sqrt(szam), 2))