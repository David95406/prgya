from math import pi
print(format(pi, ".20f"))
szam = pi


