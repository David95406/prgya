a = [2]
c = 5
b = 3
a.append(c)
print(a.index())