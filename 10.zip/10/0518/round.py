szam = 12.6
print(round(szam))