<script setup>
const api = "https://reeldev.hu/api/probavizsga/karakterek";

</script>

<template>
    <section>
        <h2>Kezdőlap</h2>

    </section>
</template>

<style scoped></style>
