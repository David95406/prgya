<script setup>

</script>

<template>
    <section>
        <h2>Saját karakterek</h2>
    </section>
</template>

<style scoped></style>
