import { mount } from '@vue/test-utils';
import { describe, expect, test } from "vitest";
import szerepjatek from '../../components/szerepjatek.vue';

describe("szerepjatek", () => {

})
