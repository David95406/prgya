<script setup>

</script>

<template>
 <nav class="py-4 text-center">
    <router-link to="/" class="m-5">Kezdőlap</router-link>
    <router-link to="/karaktereim">Karaktereim</router-link>
    <router-view></router-view>
 </nav>
</template>

<style scoped>
</style>
