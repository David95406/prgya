<script setup>
import menusav from "./components/menusav.vue";
</script>

<template>
  <header>
    <div class="container text-center">
      <h1>Szerepjáték karakterek</h1>
    </div>
  </header>
  <menusav />
  <main>

  </main>
  <footer>
    <p class="text-center">2025 &copy; Szerepjáték Karakterek</p>
  </footer>
</template>

<style scoped></style>
