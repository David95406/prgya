<template>
    <section>
        <h2>Products</h2>
        <div class="mb-3">
            <input type="search" class="form-control" placeholder="Filter...">
        </div>
        <div class="products">
            <div class="product d-flex">
                <h3>Lorum Ipse</h3>
                <p>Lórum ipse az olstás, mint tatus, és a válat prom. Aktusnak értelt: rohos, sőt szaftos rányos volt a
                    cseskesben.</p>
                <p class="price">$ 10</p>
            </div>
            <div class="product d-flex">
                <h3>HEISENBERG IPSUM</h3>
                <p>Ludum mutavit. Verbum est ex. Et ... sunt occidat. Videtur quod est super omne oppidum. Quis
                    transfretavit tu iratus es contudit cranium cum dolor apparatus. Qui curis! Modo nobis certamen est,
                    qui non credunt at.</p>
                <p class="price">$ 10</p>
            </div>
            <div class="product d-flex">
                <h3>Brainrot Ipsum</h3>
                <p>Yass queen, slay all day, bet! I'm shooketh, TBH fam, that meme's lit AF. SMH my head, bruh, that's a
                    big mood. Low-key vibin', no cap. This is the tea, sis, sippin' it. If you ain't yeeting, you ain't
                    trying. FOMO's real, YOLO, amirite? Legit squad goals. OMG, that hit different. Stan culture,
                    flexin'
                    on the gram. Bruh, I'm deceased, sending it to the group chat. Big brain energy, boomer alert. Oof,
                    that's a yikes from me, dawg. Thirst trap, TFW, can't even.</p>
                <p class="price">$ 10</p>
            </div>
        </div>
    </section>
</template>
<script setup>

</script>
<style scoped></style>