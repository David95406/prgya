<template>
    <aside>
        <h2>Cart</h2>
        <div class="cartProduct">
            <h3>Lorem ipsum</h3>
            <div class="d-flex">
                <div class="price">$ 20</div>
                <div class="quantity">Quantity: 1</div>
            </div>
        </div>
        <div class="total">Total quantity: 1</div>
        <div class="mb-3">
            <button class="btn btn-primary">Checkout ($ 200)</button>
        </div>
    </aside>
</template>
<script setup>

</script>
<style scoped></style>