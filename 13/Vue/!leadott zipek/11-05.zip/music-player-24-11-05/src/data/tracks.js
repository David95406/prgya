export const t = [
  { title: 'Game Music', artist: 'Gamer Band', file: '../assets/game-music.mp3' },
  { title: 'Intro Music', artist: 'Intro Band', file: '../assets/intro-music.mp3' },
  { title: 'Short Music', artist: 'Short Band', file: '../assets/short-music.mp3' },
];