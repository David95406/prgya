<script setup>
import GyF2 from './components/GyF2.vue'
import GyF3 from './components/GyF3.vue'
</script>

<template>
  <main>
    <h1>Gyakorló feladatok</h1>
    <h2>2. feladat</h2>
    <GyF2/>
    <h2>3. feladat</h2>
    <GyF3/>
    
  </main>
</template>

<style scoped>

</style>
