<script setup>
import BullshitGenerator from './components/BullshitGenerator.vue'
</script>

<template>
  <BullshitGenerator/>
</template>

<style scoped>

</style>
