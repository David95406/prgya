<script setup>
import Szavazas from './components/Szavazas.vue'
</script>

<template>
  <main>
    <h1>Szavazás App</h1>
    <Szavazas />
  </main>
</template>

<style scoped></style>