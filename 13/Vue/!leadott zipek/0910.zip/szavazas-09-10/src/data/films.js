const film1 = {
    "name": "Lorem Ipsum",
    "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce cursus nisl sit amet lacinia consequat. Nulla condimentum tempus sem ac porttitor.",
    "image": "../assets/film-1.jpg",
    "vote": 0
}

const film2 = {
    "name": "Ipsum Lorem",
    "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce cursus nisl sit amet lacinia consequat. Nulla condimentum tempus sem ac porttitor.",
    "image": "../assets/film-2.jpg",
    "vote": 0
}

const film3 = {
    "name": "Ipsem Lorum",
    "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce cursus nisl sit amet lacinia consequat. Nulla condimentum tempus sem ac porttitor.",
    "image": "../assets/film-3.jpg",
    "vote": 0
}

export const films = [film1, film2, film3]