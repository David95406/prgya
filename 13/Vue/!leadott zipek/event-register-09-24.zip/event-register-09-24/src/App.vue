<script setup>
import EventRegister from './components/EventRegister.vue'

</script>

<template>
  <main>
    <EventRegister />
  </main>
</template>

<style scoped>

</style>
