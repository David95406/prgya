export const books = [
    { azon: "STA-001", name: "S.T.A.L.K.E.R.: Piknik az árokparton", authors: "Arkagyij Sztrugackij, Borisz Sztrugackij", img: "/assets/book1.jpg" },
    { azon: "STA-002", name: "S.T.A.L.K.E.R.: Ház a Mocsárban", authors: "Alekszej Kalugin", img: "/assets/book2.jpg" },
    { azon: "MET-001", name: "Metró: A trilógia - bővített kiadás", authors: "Dmitry Glukhovsky", img: "/assets/book5.jpg" },
    { azon: "STA-003", name: "S.T.A.L.K.E.R.: A két mutáns", authors: "Jezsi Tumanovszkij, Roman Kulikov", img: "/assets/book3.jpg" },
    { azon: "ALI-001", name: "Alien: A Fájdalom Folyója", authors: "Christopher Golden", img: "../assets/book6.jpg" },
    { azon: "STA-004", name: "S.T.A.L.K.E.R.: A Minótaurosz Projekt", authors: "Jezsi Tumanovszkij, Roman Kulikov", img: "/assets/book4.jpg" }
  ];