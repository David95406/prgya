<script setup>
import Bevasarlolista from './components/BevasarloLista.vue';
import BevasarlolistaO from './components/BevasarlolistaO.vue';
</script>

<template>
  <main>
    <Bevasarlolista/> 
    <br><br><br>
    <!-- class:
    <BevasarlolistaO/> 
    -->
  </main>
</template>

<style scoped>


</style>
