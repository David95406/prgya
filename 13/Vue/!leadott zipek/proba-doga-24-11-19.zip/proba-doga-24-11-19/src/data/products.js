export const products = [
  {
    id: 0,
    name: "Apple",
    price: 500,
    img: "assets/apple.png"
  },
  {
    id: 1,
    name: "Bread",
    price: 100,
    img: "assets/bread.webp"
  },
  {
    id: 2,
    name: "Milk",
    price: 800,
    img: "assets/milk.png"
  },
];