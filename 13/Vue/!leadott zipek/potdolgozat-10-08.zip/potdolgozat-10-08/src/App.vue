<script setup>
import Telek from './components/Telek.vue';
</script>

<template>
  <header>
    <h1>Plots for sale App</h1>
  </header>
  <main>
    <Telek />
  </main>
  <footer>
    <p>
      &copy; Plots for sale App
    </p>
  </footer>
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style>
