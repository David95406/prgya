<script setup>
import { ref, watchEffect } from 'vue';
import { plots } from '../assets/plots';

const telkek = ref([])
plots.forEach((plot) => {
    telkek.value.push(plot)
})

const telekSzelesseg = ref("")
const telekHosszusag = ref("")
const telekAra = ref("")

const sortTelkek = (() => {
    telkek.value = telkek.value.sort((a, b) => a['ar'] - b['ar'])
})
watchEffect(() => { sortTelkek() })

const addTelek = (() => {
    telkek.value.push({
        "szelesseg": telekSzelesseg.value,
        "hosszugas": telekHosszusag.value,
        "ar": telekAra.value * 1000000
    })

    telekSzelesseg.value = ""
    telekHosszusag.value = ""
    telekAra.value = ""
    alert("sikeres hozzaadas!")
})

const increasePrice = ((index) => {
    telkek.value[index]["ar"] *= 2
})

const clearPlots = (() => {
    if (confirm("Biztos benne?")) {
        telkek.value = []
        plots.forEach((plot) => {
            telkek.value.push(plot)
        })
    }
})
</script>

<template>
    <form @submit.prevent="addTelek" v-if="telkek.length < 5">
        <label for="telekSzelesseg">Width (meter): </label>
        <input type="number" v-model="telekSzelesseg" name="telekSzelesseg"><br>

        <label for="telekHosszusag">Length (meter): </label>
        <input type="number" v-model="telekHosszusag" name="telekHosszusag"><br>

        <label for="telekAra">Price (million HUF)</label>
        <input type="number" v-model="telekAra" name="telekAra"><br>
        <button type="submit">Add To List</button>
    </form>

    <div v-else>
        <table>
            <thead>Telkek</thead>
            <tbody>
                <tr>
                    <th>Width</th>
                    <th>Length</th>
                    <th>Price</th>
                    <th>Price inc</th>
                </tr>
                <tr v-for="(plot, index) in telkek" :class="plot['ar'] >= 3000000 ? 'felsoar' : ''">
                    <td>{{ plot["szelesseg"] }}m</td>
                    <td>{{ plot["hosszugas"] }}m</td>
                    <td>{{ plot["ar"] }} Ft</td>
                    <td>
                        <button @click="increasePrice(index)" v-if="plot['ar'] < 3000000">Increase</button>
                    </td>
                </tr>
            </tbody>
        </table>
        <button @click="clearPlots()">Clear</button>
    </div>
</template>
<style scoped>
.felsoar {
    background-color: red;
}
</style>