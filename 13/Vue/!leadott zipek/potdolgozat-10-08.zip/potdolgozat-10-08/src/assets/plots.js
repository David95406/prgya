const plot1 = {hosszugas: 100, szelesseg: 120, ar: 9000000}
const plot2 = {hosszugas: 30, szelesseg: 30, ar: 2000000}

export const plots = [plot1, plot2]
