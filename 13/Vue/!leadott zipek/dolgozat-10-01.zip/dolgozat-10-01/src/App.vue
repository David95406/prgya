<script setup>
import Bevasarlolista from './components/Bevasarlolista.vue';
</script>

<template>
  <header>
    <h1>Shopping list App</h1>
  </header>
  <main>
    <Bevasarlolista />
  </main>
  <footer>
    <p>All rights reserved!</p>
  </footer>
</template>

<style scoped>
</style>
