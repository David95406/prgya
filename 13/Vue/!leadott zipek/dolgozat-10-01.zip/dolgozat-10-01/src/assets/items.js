const item1 = {
    name: "alma",
    price: 600
};
const item2 = {
    name: "ásványvíz",
    price: 255
};
const item3 = {
    name: "bagett",
    price: 300
};

export const its = [item1, item2, item3];