export const CRUD_API = "https://reeldev.hu/api/67bc7bf8042eb167384400" 
export const CRUD_API_PLANETS = "https://reeldev.hu/api/67bc7bf8042eb167384400/planets"
export const UPPERCASE_ID = "67ebc7c9a5fd9"