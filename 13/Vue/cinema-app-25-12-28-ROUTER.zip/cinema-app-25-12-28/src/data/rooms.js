export const roomsData = [{
    id: "Room 1",
    seats: [
      [false, false, false, false],
      [false, false, false, false],
      [false, false, false, false],
      [false, false, false, false],
    ],
  },
  {
    id: "Room 2",
    seats: [
      [false, false, false, false],
      [false, false, false, false],
      [false, false, false, false],
    ],
  },
];