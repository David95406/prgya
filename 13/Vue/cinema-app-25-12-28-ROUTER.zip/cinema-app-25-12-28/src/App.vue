<script setup>
import { movieDatas } from './data/movies';
import { roomsData } from './data/rooms';
import { screeningsData } from './data/screenings';
import { ref } from 'vue';

</script>

<template>
  <header>
    <h1>Cinema App</h1>
  </header>
  <main>
    <router-view />
  </main>
  <footer>
    <p>Copyright &copy;</p>
  </footer>
</template>

<style scoped>

</style>
