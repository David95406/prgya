<script setup>

</script>

<template>
    <section>
        <h2>Film</h2>
    </section>
</template>

<style scoped>
    
</style>