<script setup>

</script>

<template>
    <section>
        <h2>FilmList</h2>
        <p>
            <router-link to="film">Tovább</router-link>
        </p>
    </section>
</template>

<style scoped>
    
</style>