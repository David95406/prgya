<script setup>

</script>

<template>
    <section>
        <h2>Success reserved</h2>
    </section>
</template>

<style scoped>
    
</style>