const users = [
    { name: 'John', surname: 'Doe' },
    { name: 'Jane', surname: 'Smith' },
    { name: 'Michael', surname: 'Johnson' },
    { name: 'Emily', surname: 'Davis' },
    { name: 'William', surname: 'Brown' }
];

export default users;