import { reactive } from "vue";

export const state = reactive({
    product: null
})