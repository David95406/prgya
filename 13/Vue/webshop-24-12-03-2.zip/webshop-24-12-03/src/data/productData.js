export const p = [{
    "name": "Brainrot starter pack",
    "desc": "A pack of 3 brainrots",
    "price": 42,
}, {
    "name": "Leon coin",
    "desc": "A coin with Leon's face on it",
    "price": 10,
}, {
    "name": "Leon plushie",
    "desc": "A plushie of Leon",
    "price": 20,
}, {
    "name": "Leon's hat",
    "desc": "A hat that looks like Leon's",
    "price": 15,
}
]