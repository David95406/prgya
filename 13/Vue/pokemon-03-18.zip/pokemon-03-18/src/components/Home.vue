<script setup>
import SearchBar from './SearchBar.vue';

defineOptions({
    name: 'Home'
})
</script>

<template>
    <div>
        <SearchBar />
    </div>
</template>
