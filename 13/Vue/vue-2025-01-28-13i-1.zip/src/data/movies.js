export const movieDatas = [
    {
      id: 1,
      title: "Alien: Romulus",
      description: "While scavenging the deep ends of a derelict space station, a group of young space colonists come face to face with the most terrifying life form in the universe.",
      image: "assets/alien-romolus.jpg",
    },
    {
      id: 2,
      title: "Alien: Covenant",
      description: "The crew of a colony ship, bound for a remote planet, discover an uncharted paradise with a threat beyond their imagination, and must attempt a harrowing escape.",
      image: "assets/alien-covenant.jpg",
    },
  ];