export const screeningsData = [
    {
        movieId: 1,
        roomId: "Room 1",
        time: "14:00",
    },
    {
        movieId: 1,
        roomId: "Room 2",
        time: "17:30",
    },
    {
        movieId: 1,
        roomId: "Room 1",
        time: "22:00",
    },
    {
        movieId: 2,
        roomId: "Room 1",
        time: "15:00",
    },
    {
        movieId: 2,
        roomId: "Room 1",
        time: "20:00",
    },
];