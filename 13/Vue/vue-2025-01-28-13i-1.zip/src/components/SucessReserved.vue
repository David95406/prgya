<template>
    <section>
        <h2>Success Reserved</h2>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nesciunt optio aperiam quis quasi at magni sapiente eaque non. Recusandae delectus libero in totam minima esse a quidem quaerat dolor ipsa.</p>
        <ul>
            <li>Lorem ipsum dolor sit</li>
            <li>Lorem ipsum dolor sit</li>
            <li>Lorem ipsum dolor sit</li>
        </ul>
        <hr>
        <p><router-link to="/">&laquo; Back</router-link></p>
    </section>
</template>
