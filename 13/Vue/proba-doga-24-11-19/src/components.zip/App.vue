<script setup>
import { ref, watch } from 'vue';
import { products as productsFile } from './data/products';
import Product from './classes/Product';
import Kosar from './components/Kosar.vue'
import Fizetes from './components/Fizetes.vue'

const products = ref([])
productsFile.forEach((egyProduct) => {
  products.value.push(new Product(
    egyProduct["id"],
    egyProduct["name"],
    egyProduct["price"],
    egyProduct["img"]
  ))
})
const kosar = ref([])
const addToKosar = ((index, product) => {
  if (!kosar.value.includes(product)) {
    kosar.value.push(product)
    /*
    if (egyProduct.getId() == products.value[index].getId()) {
      kosar.value[index].setDarabszam(
        kosar.value[index].getDarabszam() + 1
      )
      return
    }
      */
  }
  var uj = products.value[index]
  uj.setDarabszam(1)
  kosar.value.push(
    uj
  )

})

const kosarSize = ref(kosar.length)
watch(kosar.value, (() => {
  /*
  var ids = []
  kosar.value.forEach((product) => {
    console.log(product.getId())
    if (!ids.includes(product.getId())) {
      ids.push(product.getId())
    }
  })
  console.log(ids)
  kosarSize.value = ids.length
  */
}))

const isKosar = ref(false)
const goToKosar = (() => {
  isKosar.value = true
  return true
})
</script>

<template>
  <header>
    <button @click="goToKosar" .disabled="kosarSize == 0">
      <p>Kosár {{ kosarSize }}</p>
    </button>
  </header>
  <main>
    <section v-if="!isKosar">
      <div v-for="(product, index) in products">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" .src="product.getImg()" .alt="product.getName()">
          <div class="card-body">
            <h5 class="card-title">{{ product.getName() }}</h5>
            <p class="card-text">{{ product.getPrice() }} Ft</p>
            <a class="btn btn-primary" @click="addToKosar(index, product)">Kosárba</a>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div v-if="isKosar">
        <Kosar :kosar="kosar" />
      </div>
    </section>
  </main>
  <footer>
    <p>&copy;Copyright</p>
  </footer>
</template>

<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}

.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}

.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}

footer header {
  text-align: center;
}
</style>
