<script setup>
import { defineProps, ref, watch } from 'vue';
import Product from '../classes/Product';

const props = defineProps({
    kosar: Array
})


</script>

<template>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Termék</th>
                    <th scope="col">darabszám</th>
                    <th scope="col">Ár</th>
                    <th scope="col">Törlés</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="egyProduct in props.kosar">
                    <th scope="row">{{ egyProduct.getName() }}</th>
                    <td>{{ egyProduct.getDarabszam() }}</td>
                    <td>{{egyProduct.getPrice()}}</td>
                    <td>Törlés</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<style scoped></style>