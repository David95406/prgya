package com.example.pizzeriaalap;

public class PizzaTest {
    public static void main(String[] args) {

    }
}
