package com.example.pizzeriaalap;

public interface iPizza {
    int HUSZONKETTOCMPIZZA = 2200;
    int HARMINCKETTOCMPIZZA = 3200;
    int NEGYVENOTCMPIZZA = 4500;
    int AZONNALISZALLITAS = 990;
    int KESOBBISZALLITAS = 1990; // Továbbá az ellenőrzésnél figyeljünk arra, hogy nem adhatnak meg a mai napnál régebbi dátumot!
    int TOLTOTTPIZZAFELAR = 1000;

}
